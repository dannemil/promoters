The R script all-heatmaps.R expects to find the following FASTA data files in the same directory as the script:

promoters1099Hs-EPD.fa  # Homo sapiens
promoters1099Dm-EPD.fa  # Drosophila melanogaster
promoters1099Sc-EPD.fa  # Saccharomyces cerevisiae
promoters1099Mm-EPD.fa  # Mus musculus

