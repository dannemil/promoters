################################################################################################
#
# Software to accompany:
#
# Dannemiller, JL (2020) Mutual information reveals a homonucleotide bias at 6 bp distance in 
# promoters. Manuscript under review (June 29, 2020) at Bioinformatics - Oxford University Press.
#
# This script: 
# 1) reads in sequences in FASTA format aligned at their putative Transcription Start Sites (TSS)
# 2) computes matrix Mutual information (MI) for all pairwise positions in a subrange of the 
#     original sequences
# 3) produces a heatmap of the MI matrix
# 4) computes average MI vs distance (between positions) for distances 1 to 21 bp
# 5) plots the MI vs. distance function 
#
# NOTE: This software was written to run on the OSX operating system. 
## It shouldn't be too hard to modify it to run on Linux.
## The program checks for the OSX operating system, and halts if it encounters anything else.
################################################################################################




# Include the following libraries. Install if not already installed.

######### From Bioconductor

# install.packages("BiocManager")
library(BiocManager)

# BiocManager::install(c("GenomicFeatures", "AnnotationDbi"))
library("GenomicFeatures")
library("AnnotationDbi")

### BiocManager::install('Biostrings')
library('Biostrings')

#BiocManager::install("biomaRt")
library("biomaRt")

#############################

########## additional R packages

library(ggplot2)
library(readr)
library(digest)
library(seqinr)
library(tidyverse)

install_github("ELIFE-ASU/rinform")
library(rinform)

library(mpmi)
library(infotheo)
library(modeest)
library(xattrs)
library(here)


################################


# Determine what operating system is being used.

get_os <- function(){
  sysinf <- Sys.info()
  if (!is.null(sysinf)){
  os <- sysinf['sysname']
  if (os == 'Darwin')
    os <- "osx"
  } else { ## mystery machine
    os <- .Platform$OS.type
    if (grepl("^darwin", R.version$os))
      os <- "osx"
    if (grepl("linux-gnu", R.version$os))
      os <- "linux"
  }
  tolower(os)
}

opsys <- get_os()

if (opsys != "osx") {
  
  cat("This program was written to run under the OSX operating system. Now halting.")
  
  stop()
  
} else {
  
  cat("Running on OSX.")
  
}



########### miscellaneous settings

# Get the name of this R script and the path to that file.
args <- commandArgs()

scriptName <- args[substr(args,1,7) == '--file=']

if (length(scriptName) == 0) {
  scriptName <- rstudioapi::getSourceEditorContext()$path
} else {
  scriptName <- substr(scriptName, 8, nchar(scriptName))
}

pathName <- substr(
  scriptName, 
  1, 
  nchar(scriptName) - nchar(strsplit(scriptName, '.*[/|\\]')[[1]][2])
)


species.names <- c("Homo sapiens","Drosophila melanogaster","Saccharomyces cerevisiae","Mus musculus")

species.shorts <- c("Hs","Dm","Sc","Mm")

funcDir <- c(paste0(pathName,"/functions/"))
heatDir <- c(paste0(pathName,"/heatmaps/"))
plotDir <- c(paste0(pathName,"/plots/"))

#################################



# Source the required custom functions.



# sANDp()
##### in function directory as func_csf.R //// gets path and name of currently running R script

source(paste0(funcDir,"func_sANDp.R"))

scr.pth <- sANDp()




# Read in the sequence data for the four species in FASTA format. 
## Split into a matrix with rows as genes and columns as positions (from 1:1100).
# 
# Relative to the TSS, the sequences range from -1000 to + 99 with TSS at +1.
# 
# NOTE: The code that reads in the sequences assumes that the data files are in
## the same directory as this R script, and that the data files are named:
# 
# promoters1099Hs-EPD.fa  # Homo sapiens
# promoters1099Dm-EPD.fa  # Drosophila melanogaster
# promoters1099Sc-EPD.fa  # Saccharomyces cerevisiae
# promoters1099Mm-EPD.fa  # Mus musculus


          
########## Read in sequences########################

# Sequences were originally downloaded from the Eukaryotic Promoter Database with the setting
#   to only retrieve "Only the most representative promoter for a gene" 
          
ng <- c(rep(NA,4))  # hold the sample sizes (number of sequences) across the four species

# Homo sapiens
          
promoter.seq.Hs.epd <- readDNAStringSet("promoters1099Hs-EPD.fa", 
                                         format="fasta",
               nrec=-1L, skip=0L, seek.first.rec=FALSE,
               use.names=TRUE, with.qualities=FALSE)


ng[1] <- length(promoter.seq.Hs.epd)


# Drosophila melanogaster
          
promoter.seq.Dm.epd <- readDNAStringSet("promoters1099Dm-EPD.fa", 
                                         format="fasta",
               nrec=-1L, skip=0L, seek.first.rec=FALSE,
               use.names=TRUE, with.qualities=FALSE)


ng[2] <- length(promoter.seq.Dm.epd)


# Saccharomyces cerevisiae
          
promoter.seq.Sc.epd <- readDNAStringSet("promoters1099Sc-EPD.fa", 
                                         format="fasta",
               nrec=-1L, skip=0L, seek.first.rec=FALSE,
               use.names=TRUE, with.qualities=FALSE)


ng[3] <- length(promoter.seq.Sc.epd)



# Mus musculus
          
promoter.seq.Mm.epd <- readDNAStringSet("promoters1099Mm-EPD.fa", 
                                         format="fasta",
               nrec=-1L, skip=0L, seek.first.rec=FALSE,
               use.names=TRUE, with.qualities=FALSE)

ng[4] <- length(promoter.seq.Mm.epd)

# put into list

promotersEPD.All <- list(Hs=promoter.seq.Hs.epd,
                         Dm=promoter.seq.Dm.epd,
                         Sc=promoter.seq.Sc.epd,
                         Mm=promoter.seq.Mm.epd)




# Split the sequences into vectors of single DNA letters, each 1100 bp wide
## if they have not already been split.

# set up list to hold the single character matrix sequences

fasta.by.lett.all <- list()

# This checks in the current directory for these csv sequence files.

for (i in 1:4) {

  if (file.exists(paste0("fasta.by.lett.",species.shorts[i],".epd.csv"))) {
    
    cat(paste0("fasta.by.lett.",species.shorts[i],".epd.csv"),"exists. Reading...")

  fasta.by.lett.all[[i]] <- data.frame(read_csv(paste0("fasta.by.lett.",species.shorts[i],".epd.csv")))
  
} else {
  
  # split sequences into a character matrix ng[i] x 1100 where ng[i] is the number of sequences
  
  fasta.by.lett.all[[i]] <- str_split_fixed(as.character(promotersEPD.All[[i]]),"",n=Inf)
  
  # if split correctly save as csv file
  
  if (dim(fasta.by.lett.all[[i]])[1] == ng[i] && dim(fasta.by.lett.all[[i]])[2] == 1100) {
    
    cat(paste0("The ",species.shorts[i]," sequences split correctly. Saving file. \n"))
    
    write.csv(fasta.by.lett.all[[i]],file=paste0("fasta.by.lett.",species.shorts[i],".epd.csv"), 
          quote = FALSE,
            eol = "\n", na = "NA",row.names = FALSE)
  
  } else {
  
  cat(paste0("The ",species.shorts[i]," sequences did not split correctly. Halting.\n"))
  stop()
    
  }
  
}

} #end species loop

# create an individual, named character matrix for each species

fasta.by.lett.Hs.epd <- fasta.by.lett.all[[1]]
fasta.by.lett.Dm.epd <- fasta.by.lett.all[[2]]
fasta.by.lett.Sc.epd <- fasta.by.lett.all[[3]]
fasta.by.lett.Mm.epd <- fasta.by.lett.all[[4]]



# Save out as R data files both the DNAStringSet list of promoter sequences
## and the single character matrix list for all species.


# DNAStringSet
if (!file.exists("promotersEPD.All.Rds")) {
  
  saveRDS(promotersEPD.All,"promotersEPD.All.Rds")
  
} else {
  
}

# csv matrix of sequences

if (!file.exists("fasta.by.lett.all.Rds")) {
  
  saveRDS(fasta.by.lett.all,"fasta.by.lett.all.Rds")
  
} else {
  
}


####################### Begin MI calculation and plot heatmaps ######################


# allocate storage for the subrange (usually 100 x 100) MI matrices
# There are (4 species *  10 subranges/species) = 40 heatmaps each of which is 100 x 100

# store in array for latter computation of MI vs. distance functions.
mi.all <- array(rep(NA,4*100*100*10),dim=c(100,100,10,4))

wd <- c(100) # width of standard heatmap in bp

# step through from -950 to -50 by wd (100) and generate a heatmap
## for each of these 100 bp subranges for each species

init.p <- c(-950)  # first heatmap starts at this position re: TSS

# lay out the limits for the individual heatmaps
rng.lims <- matrix(c(c(seq(init.p,-50,wd)),c(seq((init.p + wd -1),51,wd))),ncol=2,byrow=FALSE)

# how many of these subranges are there?
len.rngs <- nrow(rng.lims)

# convert the limits re: TSS into actual indices in the data matrices
mtx.df <- rng.lims + 1001  # This assumes the TSS is at +1

# prefixes to heatmap output files
ttl.vec <- c(paste0("MIheatmap-",species.shorts))

mtx.df.ttl <- species.shorts

# suffix for all heatmaps
fn.aux <- c(".pdf")


# Only the core promoter region -50 to +49 heatmaps get annotated
annots.txt <- matrix(c(rep(c(rep("",4)),9),
               c("", "TATA", "Inr", "DPE")),ncol=4,byrow=TRUE)

annots.xy <- matrix(c(40,48,   # coordinates relative to upper left corner (0,0)
               22.0,35.0,
              48.0,56.0,
               80.0,90.0,
               40.0,34.0,
               46.0,40.0),ncol=2,byrow=TRUE)



pb <- progress_bar$new(total = 4*len.rngs)


 for (g in 1:4)   {    # species

    
     for (ttl in 1:len.rngs)   {   # subranges
       
       pb$tick()
       
# x,y limits for plotting
  y.lims <- rev(c(rng.lims[ttl,1],rng.lims[ttl,2]))    

  y.breaks.ax <- rev(c(seq(rng.lims[ttl,1],rng.lims[ttl,2],10)))   

  ylabs.ax <- as.character(c(y.breaks.ax))
  
  x.lims <- c(rng.lims[ttl,1],rng.lims[ttl,2])    

  x.breaks.ax <- c(seq(rng.lims[ttl,1],rng.lims[ttl,2],10))  

  xlabs.ax <- as.character(c(x.breaks.ax))
  

if (ttl == 10) {   # if the last interval (-50 to +49) adjust for TSS at +1
  
  ylabs.ax <- rev(c(as.character(c(seq(-50,-10,10))),"+1",as.character(c(seq(11,41,10)))))
  
  xlabs.ax <- c(as.character(c(seq(-50,-10,10))),"+1",as.character(c(seq(11,41,10))))
  
} else {

}



# title template
ttl.stem <- paste0(c("MI for "),rng.lims[ttl,1]," to ",rng.lims[ttl,2]," bp re: TSS ")

# full title
title.txt <- paste0(ttl.stem,species.names[g]," Promoters")

# isolate the specific limits for this heatmap
mtx.limsbp <- rng.lims[ttl,]
fivep <- mtx.df[ttl,1]     # 5' limit matrix index
threep <- mtx.df[ttl,2]    # 3' limit matrix index


# compute the MI matrix using the dmi function from the mpmi package

mtx <- mpmi::dmi(fasta.by.lett.all[[g]][,c(fivep:threep)])$mi # using $bcmi bias corrects $mi

# store in the mi.all array for later computations
mi.all[,,ttl,g] <- mtx  # ttl=subrange index; g = species index


# placement of core promoter element annotations if ttl = 10 (-50 to +49)
place.annots <- annots.xy + x.lims[1] 


# The diagonal will be filled with the modal MI level. Otherwise, it dominates the heatmap.
# The diagonal entries do not speak to the MI v distance question, so they can be safely ignored.

   diag(mtx) <- modeest::mlv(mtx[upper.tri(mtx,diag=FALSE)],method="shorth")

   
# The heatmaps use the logs of the MI values as a compressive transformation to preserve detail.

   #     print(max(log(mtx)))

     # reformat the MI matrix into three columns X, Y, MI 
 x <- c(mtx.limsbp[1]:(mtx.limsbp[2]))
 y <- c(mtx.limsbp[1]:(mtx.limsbp[2]))
 data <- expand.grid(X=x, Y=y)
 data$MI <- as.vector(log(mtx))   # <<<<< plot log(MI)


heat.plt <- ggplot(data=data, aes(X, Y)) +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
  geom_tile(aes(fill = MI)) +
  scale_y_reverse(position="left",
                  name="Position (bp re: TSS)",
                  limits=y.lims,
                  breaks=y.breaks.ax,
                  labels=ylabs.ax,
                  expand=c(0,0)) +
  scale_x_continuous(position="top",
                  name="Position (bp re: TSS)",
                  limits=x.lims,
                  breaks=x.breaks.ax,
                  labels=xlabs.ax,
                  expand=c(0,0)) +
  ggtitle(label=title.txt) +
     theme(plot.title = element_text(hjust = 0.5)) +
      scale_fill_gradient2(low = "white", mid = "#edeba1",
             high = "#d97467", midpoint = mlv(data$MI), space = "Lab",
             na.value = "white", guide = "colourbar", aesthetics = "fill") +
  labs(fill = c(as.expression(bquote(log(MI))))) +
  annotate(geom="text",x=place.annots[c(1:4),2],y=place.annots[c(1:4),1],label=annots.txt[ttl,],
           size=c(3)) +
  geom_segment(aes(x=place.annots[5,1],
                   y=place.annots[5,2],
                   xend=place.annots[6,1],
                   yend=place.annots[6,2]),
               size=c(0.5),color=c("gray60")) +
  coord_fixed(ratio=c(1.0)) +
     
     theme(plot.margin = margin(1, 1, 1, 1, "cm"))

# uncomment the print statement to see the heatmap in the RStudio Plots pane.
# This is slow in rendering to the screen, but much faster if the plot is simply saved in a file.

# print(heat.plt)

############## END ggplot heatmap ########################
  

# save the heatmap as a pdf
fname.stem <- paste0(ttl.vec[g],as.character(rng.lims[ttl,1]))

############################ 
 plotfname <- paste0(heatDir,fname.stem,fn.aux)
#############################

ggsave(plotfname, plot = heat.plt, device = "pdf",
  scale = 1, width = 20, height = 20, units = c("cm"),
  dpi = 300) 

# This stores the name of this R script in the meta.data for the heatmap file, so that later, that pdf can be queried to determine which R script produced it using the syntax:

# xattrs::get_xattr(paste0(path-to-heatmap-pdf,"produced.by.file")

# Attach this R script name to the heatmap pdf metadata that was just saved.
          xattrs::set_xattr(plotfname,"produced.by.file",
                            scr.pth[1])
          

 }    # ranges ttl


}  #  species  g




# Compute average MI vs. distance functions for each of these 40 heatmaps.
# 
# The MI matrices are in the array mi.all.

# mi.all is 100 x 100 x 10 x 4   (MI matrix) * (subranges) * (species).



################################################################################################
# MI is averaged along the off-diagonals. Each off-diagonal from 1 bp off the major diagonal
## to 21 bp off the major diagonal corresponds to a fixed distance between pairs of positions.
# For example, the off-diagonal that is 6 bp off the major diagonal runs from (1,7) to (94,100).
# The first index is the row in the MI matrix with the "origin being the upper left corner.
# To ensure that equal numbers of MI values along these different off-diagonals are averaged,
## if the largest distance is 21 bp, then 100 - 21 -1 contiguous MI values can be averaged for
## for each distance. That is, the distance=21 bp off-diagonal runs from (1,22) to (79,100).
## This contrains the number of MI values that can be averaged to 79, and that is used regardless
## of distance to equalize the number of MI values contributing to each average MI.

################################################################################################

# Hs mi v dist from off-diagonal means

maxd <- c(21) # bp Maximum distance for which average MI is computed.

wid <- wd # set the width of these heatmap windows to the value used to compute them: wd = 100

# initialize an array to hold the 10 avgMI vs. distance functions for each of the 4 species
mi.V.dist <- array(rep(NA,21*len.rngs*4),dim=c(21,len.rngs,4))

# initialize an array to hold the standard deviations of these off-diagonal values
mi.V.dist.sd <- array(rep(NA,21*len.rngs*4),dim=c(21,len.rngs,4))

for (g in 1:4)   {    # species
  
  for (ttl in 1:len.rngs)  {   # number of subranges (see setting above)

# This gives the 21 x 1 vector of average MI values for a given subrange in a given species.
    
       mi.V.dist[c(1:21),ttl,g] <- mapply(function(dg) {mean(diag(mi.all[c(c(dg:(dg+(wid-maxd-1)))),,ttl,g][,c(1:(wid - maxd))]))},dg = c(2:(maxd+1)))
       
       mi.V.dist.sd[c(1:21),ttl,g] <- mapply(function(dg) {sd(diag(mi.all[c(c(dg:(dg+(wid-maxd-1)))),,ttl,g][,c(1:(wid - maxd))]))},dg = c(2:(maxd+1)))
  

  } # subranges
  
} # species

# save the average mi vs. distance functions in one array in the current directory.

if (!file.exists("mi.V.dist.Rds")) {
  
  saveRDS(mi.V.dist,"mi.V.dist.Rds")
  
  } else {
  
  }

# save the SEM mi vs. distance functions in one array
# first convert all of the sd values into standard errors of the mean by dividing by sqrt(79).

mi.V.dist.sem<- mi.V.dist.sd/sqrt(wid - maxd)

if (!file.exists("mi.V.dist.sem.Rds")) {
  
  saveRDS(mi.V.dist.sem,"mi.V.dist.sem.Rds")
  
  } else {
  
}

@



# demonstrate how to plot MI vs. Distance for one particular subrange in one species

# Here, I will plot this function for the subrange -250 to -151 in Hs
# The subrange limits are in the matrix rng.lims
# add an index column so that the particular subrange desired can be selected by using an index

sub.range <- data.frame(index = c(1:10),
                        five.p = rng.lims[,1],
                        three.p = rng.lims[,2])

print(sub.range)
#    index five.p three.p
# 1      1   -950    -851
# 2      2   -850    -751
# 3      3   -750    -651
# 4      4   -650    -551
# 5      5   -550    -451
# 6      6   -450    -351
# 7      7   -350    -251
# 8      8   -250    -151
# 9      9   -150     -51
# 10    10    -50      49

# mi.V.dist is a 21 x 10 x 4 array: 
## distance is 1:21 bp
## subrange is indexed as above by 1:10
## species is 1:4
### [1] "Homo sapiens"                [2] "Drosophila melanogaster" 
### [3] "Saccharomyces cerevisiae"    [4] "Mus musculus"  

# to plot the MI vs Distance function for subrange from -250 to -151 re: TSS in Hs
### select mi.V.dist[,8,1]

# the same is true for the mi.V.dist.sem selection
### select mi.V.dist.sem[,8,1]

subr <- c(8)  # select -250 to -151
spc <- c(1)   # select Home sapiens

mi.V.dist.sel <- data.frame(Distance = c(1:21),
                            mean=mi.V.dist[,subr,spc],
                            sem=mi.V.dist.sem[,subr,spc])

titl <- c(paste0("MI vs. Distance (bp) from ",species.names[spc]," Promoter Range ",
                 sub.range[subr,2]," to ",sub.range[subr,3]," bp re: TSS"))
subtitl <- c("n = 79 MI values averaged per point")

mivdist.plt <- ggplot(data=mi.V.dist.sel,aes(x=Distance,y=mean)) +
     geom_point() +
     geom_line() +
    geom_errorbar(data=mi.V.dist.sel,aes(x=Distance,
                                         ymin=mean-sem,
                                         ymax=mean+sem),
                                          width=0.4, size=0.5) +
     theme_bw() +
     theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank()) +
     scale_x_continuous(limits=c(0,22),
                        breaks=c(seq(0,22,2)),
                        name=c("Distance (bp)")) +
      scale_y_continuous(name=c("Average MI")) +
    ggtitle(label=titl,
                  subtitle=subtitl) +
          theme(plot.title = element_text(hjust = 0.5)) +
          theme(plot.subtitle = element_text(size=c(8),hjust = 0))  +
          theme(legend.position = c(0.8, 0.8))

print(mivdist.plt)

  
plotfname <- paste0(plotDir,species.shorts[spc],"-miVdist",sub.range[subr,2],"-to",sub.range[subr,3],".pdf")

ggsave(plotfname, plot = mivdist.plt, device = "pdf",
  scale = 1, width = 20, height = 15, units = c("cm"),
  dpi = 300) 
          
          xattrs::set_xattr(plotfname,"produced.by.file",
                            scr.pth[1])


############# END ###########################################################
