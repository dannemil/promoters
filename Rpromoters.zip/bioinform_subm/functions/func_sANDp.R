# script to retrieve the current script and path names

sANDp <- function()  {
     
     nms <- c(rep(NA,2))

args = commandArgs()

scriptName = args[substr(args,1,7) == '--file=']

if (length(scriptName) == 0) {
     scriptName <- rstudioapi::getSourceEditorContext()$path
} else {
     scriptName <- substr(scriptName, 8, nchar(scriptName))
}

pathName = substr(
     scriptName, 
     1, 
     nchar(scriptName) - nchar(strsplit(scriptName, '.*[/|\\]')[[1]][2])
)

          nms <- c(scriptName,pathName)

     return(nms)

}
